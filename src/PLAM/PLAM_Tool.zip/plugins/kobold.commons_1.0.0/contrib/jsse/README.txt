You've to manually fetch JSSE from Sun if you've problems with xmlrpc2-devel because of license issues.
Download from http://java.sun.com/products/jsse/

Team Werkbold